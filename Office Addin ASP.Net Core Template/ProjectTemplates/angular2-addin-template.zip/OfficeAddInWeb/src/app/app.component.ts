import { Component } from '@angular/core';

@Component({
    selector: '$safeprojectname$',
    templateUrl: 'app/app.component.html',
    styleUrls: ['app/app.component.css']
})

export class AppComponent {
    constructor() {
        console.log('Hello Angular2');
    }
}