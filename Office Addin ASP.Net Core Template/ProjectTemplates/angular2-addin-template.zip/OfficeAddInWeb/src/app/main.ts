import { bootstrap } from '@angular/platform-browser-dynamic';
import {AppComponent} from "./app.component";

if (window.hasOwnProperty('Office')) {
    Office.initialize = (reason) => {
        console.log('Office is initialized');
        bootstrap(AppComponent);
    };
}
else {
    bootstrap(AppComponent);
}