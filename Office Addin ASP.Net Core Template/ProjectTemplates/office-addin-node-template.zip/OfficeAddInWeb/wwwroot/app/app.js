﻿(function () {
    'use strict';

    $(document).ready(function () {
        Office.initialize = function (reason) {
            console.log(reason);
        }
    });
})();